var searchData=
[
  ['gammaramp_0',['gammaRamp',['../group__vidio.html#ga8c9a0e88c149ff7eff6c49265e90b862',1,'_NVVIOGAMMACORRECTION']]],
  ['gammaramp10_1',['gammaramp10',['../group__vidio.html#ga0f4aaff76fea7e7e703f9ffe6a9e7541',1,'_NVVIOGAMMACORRECTION::gammaRamp10'],['../group__vidio.html#gafcaefba98fd10cabac263773084a1ff9',1,'_NVVIOGAMMACORRECTION::@62::gammaRamp10']]],
  ['gammaramp8_2',['gammaramp8',['../group__vidio.html#gaa73c0bf6bb2339cd4505c43ba60fbc9b',1,'_NVVIOGAMMACORRECTION::gammaRamp8'],['../group__vidio.html#gabcf42bf009441132c38e81ae794190c9',1,'_NVVIOGAMMACORRECTION::@62::gammaRamp8']]],
  ['gpiopinblue_3',['gpioPinBlue',['../group__vidio.html#gafa98c150150e26adfafc35a3c8e8b764',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_RGBW']]],
  ['gpiopingreen_4',['gpioPinGreen',['../group__vidio.html#gac64bfc63eb032b8beea5e364e1b9c94b',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_RGBW']]],
  ['gpiopinred_5',['gpioPinRed',['../group__vidio.html#ga015308f09fbca43441e916b89414d6cc',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_RGBW']]],
  ['gpiopinsinglecolor_6',['gpioPinSingleColor',['../group__vidio.html#ga1ad056ac67ea56729381ce1466702912',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_SINGLE_COLOR']]],
  ['gpiopinwhite_7',['gpioPinWhite',['../group__vidio.html#ga4302213f628d60d98632d3439bb4f5b1',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_RGBW']]],
  ['gpuactiverendertimeus_8',['gpuActiveRenderTimeUs',['../group__vidio.html#gab2d1dbacc46dc86426937279395745c1',1,'_NV_LATENCY_RESULT_PARAMS::FrameReport']]],
  ['gpucount_9',['gpucount',['../group__vidio.html#gaac83e9820530bfa4d011e38faa7c6179',1,'NV_COMPUTE_GPU_TOPOLOGY_V1::gpuCount'],['../group__vidio.html#gaf4b85d3323c00fdc09a40ce821a8a6fc',1,'_NV_COMPUTE_GPU_TOPOLOGY_V2::gpuCount']]],
  ['gpuframetimeus_10',['gpuFrameTimeUs',['../group__vidio.html#ga2be61eaa2b757435d1b08f46ed9d74ec',1,'_NV_LATENCY_RESULT_PARAMS::FrameReport']]],
  ['gpuid_11',['gpuId',['../group__vidio.html#gad2ffba6a0981d5aa53bf1dae122c8e52',1,'NV_DISPLAY_PATH']]],
  ['gpusupport_12',['gpuSupport',['../group__vidio.html#ga2bc6d436c953b83424909036021cce73',1,'_NVDRS_PROFILE_V1']]],
  ['grpcount_13',['grpCount',['../group__vidio.html#ga10fb675745fa23007afcfc9b873edc38',1,'_NV_GPU_CLIENT_ILLUM_ZONE_CONTROL_DATA_PIECEWISE_LINEAR']]],
  ['grpidletimems_14',['grpIdleTimems',['../group__vidio.html#gaf1c7d3f8bcef36daf307274732fec0c3',1,'_NV_GPU_CLIENT_ILLUM_ZONE_CONTROL_DATA_PIECEWISE_LINEAR']]]
];
