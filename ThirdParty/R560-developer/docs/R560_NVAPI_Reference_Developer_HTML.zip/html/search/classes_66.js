var searchData=
[
  ['framereport',['FrameReport',['../struct___n_v___l_a_t_e_n_c_y___r_e_s_u_l_t___p_a_r_a_m_s_1_1_frame_report.html',1,'_NV_LATENCY_RESULT_PARAMS']]]
];
