var searchData=
[
  ['x_0',['x',['../group__vidio.html#ga9f66836851a0cfa1c8a1106f2a628083',1,'NV_VIEWPORTF::x'],['../group__vidio.html#ga8622f8b6003b39821f22c082757ed765',1,'_NVVIOOUTPUTREGION::x']]],
  ['xratio_1',['xRatio',['../group__vidio.html#gaf7beef279db2b776d5adc656b60f501f',1,'NV_CUSTOM_DISPLAY']]]
];
