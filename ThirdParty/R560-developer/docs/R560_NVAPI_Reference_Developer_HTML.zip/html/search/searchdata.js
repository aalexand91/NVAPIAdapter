var indexSectionsWithContent =
{
  0: "0_abcdefghijlmnoprstuvwxyz",
  1: "_fnt",
  2: "_n",
  3: "abcdefghijlmnoprstuvwxyz",
  4: "ns",
  5: "_n",
  6: "n",
  7: "dgmnosv",
  8: "dl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules",
  8: "Pages"
};

