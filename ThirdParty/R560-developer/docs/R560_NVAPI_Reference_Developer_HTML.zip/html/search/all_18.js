var searchData=
[
  ['y_0',['y',['../group__vidio.html#ga2ff2b03806f103664f1ee11a7bd31d1e',1,'NV_VIEWPORTF::y'],['../group__vidio.html#gaae54062b4bcfb95955bdfe10f23c5726',1,'_NVVIOOUTPUTREGION::y']]],
  ['year_1',['year',['../group__vidio.html#ga3eb9036f18ca31aabc1395ecbb34f8fd',1,'_NV_LICENSE_EXPIRY_DETAILS']]],
  ['yratio_2',['yRatio',['../group__vidio.html#ga011a9e5c796b4e31b894292fde3fa142',1,'NV_CUSTOM_DISPLAY']]]
];
