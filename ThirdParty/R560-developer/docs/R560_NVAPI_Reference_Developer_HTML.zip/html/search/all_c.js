var searchData=
[
  ['lanecount_0',['laneCount',['../group__vidio.html#ga592430d0077f3c57c19bb189dc83b79f',1,'NV_DISPLAY_PORT_CONFIG']]],
  ['lastfliprefreshcount_1',['lastFlipRefreshCount',['../group__vidio.html#gaab3e79a03803df37bbc7d9c75c67468b',1,'_NV_GET_ADAPTIVE_SYNC_DATA_V1']]],
  ['lastfliptimestamp_2',['lastFlipTimeStamp',['../group__vidio.html#ga0e9d23c5ce632b786585154017ead782',1,'_NV_GET_ADAPTIVE_SYNC_DATA_V1']]],
  ['launcher_3',['launcher',['../group__vidio.html#ga6e1a9e69daecce24e32c98a1aa95b0f9',1,'_NVDRS_APPLICATION_V1::launcher'],['../group__vidio.html#gabf30b169a43a9e6fbe6ddad26d04841d',1,'_NVDRS_APPLICATION_V2::launcher'],['../group__vidio.html#ga71019a25d7ee66be99750b71c9e29c54',1,'_NVDRS_APPLICATION_V3::launcher'],['../group__vidio.html#ga0fbe59b9240c38f46700e7797c5240a1',1,'_NVDRS_APPLICATION_V4::launcher']]],
  ['licensablefeaturecount_4',['licensablefeaturecount',['../group__vidio.html#gae9b85b54142cd037e9f193ec5890ed43',1,'_NV_LICENSABLE_FEATURES_V1::licensableFeatureCount'],['../group__vidio.html#gac06d4cd93be27b19b5427c0baac17f02',1,'_NV_LICENSABLE_FEATURES_V2::licensableFeatureCount'],['../group__vidio.html#gaccde6a69bc48346e7c8580c75b957fad',1,'_NV_LICENSABLE_FEATURES_V3::licensableFeatureCount'],['../group__vidio.html#ga71504530744a8be2881f9ad62ad84a0b',1,'_NV_LICENSABLE_FEATURES_V4::licensableFeatureCount']]],
  ['licensedetails_5',['licensedetails',['../group__vidio.html#ga273cf1468a15e15d6df9110f76913290',1,'_NV_LICENSABLE_FEATURES_V1::licenseDetails'],['../group__vidio.html#gad43e3e5f5ab03cd89dc5a321eac387c6',1,'_NV_LICENSABLE_FEATURES_V2::licenseDetails'],['../group__vidio.html#ga2cd6549a41b16e8448879f44303760c9',1,'_NV_LICENSABLE_FEATURES_V3::licenseDetails'],['../group__vidio.html#ga73dd5eaa87128892544019e718d2b4ef',1,'_NV_LICENSABLE_FEATURES_V4::licenseDetails']]],
  ['licenseexpiry_6',['licenseExpiry',['../group__vidio.html#ga72e7bfa1e0ae4dccad1d72a7fbea338e',1,'_NV_LICENSE_FEATURE_DETAILS_V4']]],
  ['licenseinfo_7',['licenseinfo',['../group__vidio.html#ga00cd71d9cca8410ed116fe8e6c745fe1',1,'_NV_LICENSE_FEATURE_DETAILS_V1::licenseInfo'],['../group__vidio.html#gacc46f9574624d0722a29fce0356f9b03',1,'_NV_LICENSE_FEATURE_DETAILS_V2::licenseInfo'],['../group__vidio.html#gabb99bc71b83d5ba2742067baeefb0b9a',1,'_NV_LICENSE_FEATURE_DETAILS_V3::licenseInfo'],['../group__vidio.html#ga24c7fd53955d452fcb387673c6e65d48',1,'_NV_LICENSE_FEATURE_DETAILS_V4::licenseInfo']]],
  ['linkid_8',['linkID',['../group__vidio.html#ga0220670f546a01d2b692e2a333d70da6',1,'_NVVIOCHANNELSTATUS']]],
  ['linkinfo_9',['linkinfo',['../group__vidio.html#gac13f904990f1d0732df9c284b739e8f5',1,'NVLINK_GET_STATUS_V1::linkInfo'],['../group__vidio.html#ga40532f348c36cf6422014fe7e8f466a6',1,'NVLINK_GET_STATUS_V2::linkInfo']]],
  ['linkmask_10',['linkmask',['../group__vidio.html#gac1a1d513e7a3d95006f066a3298e5556',1,'NVLINK_GET_CAPS_V1::linkMask'],['../group__vidio.html#ga0f13506ec6acfe16d10f36f57b9393fd',1,'NVLINK_GET_STATUS_V1::linkMask'],['../group__vidio.html#ga10ca36ecb16e99dffbfe2672e2ad7bea',1,'NVLINK_GET_STATUS_V2::linkMask']]],
  ['linkrate_11',['linkRate',['../group__vidio.html#ga9743c4312a455fc5631f48906b92053f',1,'NV_DISPLAY_PORT_CONFIG']]],
  ['linkstate_12',['linkstate',['../group__vidio.html#gad0782c208d419a14f33ada80c72b2880',1,'NVLINK_LINK_STATUS_INFO_V1::linkState'],['../group__vidio.html#gaf83222086b2c5a4d3622d40c6f5481ca',1,'NVLINK_LINK_STATUS_INFO_V2::linkState']]],
  ['list_13',['Deprecated List',['../deprecated.html',1,'']]],
  ['localdeviceinfo_14',['localDeviceInfo',['../group__vidio.html#ga2feacb3dbcbf3e683ebe89e1b9243ab8',1,'NVLINK_LINK_STATUS_INFO_V2']]],
  ['localdevicelinknumber_15',['localDeviceLinkNumber',['../group__vidio.html#ga84a2535869688e3a46306949cee1e886',1,'NVLINK_LINK_STATUS_INFO_V2']]],
  ['loopproperty_16',['loopproperty',['../group__vidio.html#gae3ed4a5d011a4749f12ee80e9ccfb6ee',1,'NVLINK_LINK_STATUS_INFO_V1::loopProperty'],['../group__vidio.html#gad69bb9b3653897ee2ff904c604471b6c',1,'NVLINK_LINK_STATUS_INFO_V2::loopProperty']]],
  ['lowestnciversion_17',['lowestNciVersion',['../group__vidio.html#gaeb1ebd8c907288d95941f427b6f56518',1,'NVLINK_GET_CAPS_V1']]],
  ['lowestnvlinkversion_18',['lowestNvlinkVersion',['../group__vidio.html#ga5347105c97ce43a9eb5e7f39050bb5d1',1,'NVLINK_GET_CAPS_V1']]]
];
